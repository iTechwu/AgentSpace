import type { RuntimeToolCapability } from "@dofe-agent/domain";
import { type AgentDocumentContext, type FeishuLarkCliResourceGrant } from "@dofe-agent/services";
export declare function buildDocumentRuntimeToolCapabilities(agentDocumentContexts: AgentDocumentContext[], options?: {
    canCreateGoogleSheet?: boolean;
    feishuLarkCliResourceGrants?: FeishuLarkCliResourceGrant[];
}): RuntimeToolCapability[];
