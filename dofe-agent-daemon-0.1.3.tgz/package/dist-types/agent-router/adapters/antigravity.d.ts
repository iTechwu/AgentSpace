import type { HarnessAdapter } from "../types.ts";
export declare const antigravityAdapter: HarnessAdapter;
